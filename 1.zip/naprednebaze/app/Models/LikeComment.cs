﻿namespace app.Models
{
    public class LikeComment
    {
        public string UserId { get; set; }
        public Comment Comment { get; set; }
    }

}
